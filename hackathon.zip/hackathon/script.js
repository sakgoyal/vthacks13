const DELIMITER = "\n".charCodeAt(0);

navigator.serial.addEventListener("disconnect", () => {
	location.reload();
});

document.onclick = async () => {
	// TODOOOOOO
	window.serialEnd = true;

	const port = await navigator.serial.requestPort().catch(error => {
		console.log(error);
	});

	await port.open({ baudRate: 9600 }).catch(() => {
		port.close();
	});

	if (!port.readable) return;

	//document.onclick = null;
	//TODOOOOO
	document.onclick = () => window.serialEnd = true;

	const reader = port.readable.getReader();

	let output = [];

	while (true) {
		const { value } = await reader.read();

		if (value) {
			output.push(...Array.from(value));

			let commandCount = 0;
			for (let i = 0; i < output.length; i++) {
				if (output[i] === DELIMITER) {
					commandCount++;
				}
			}

			for (let i = 0; i < commandCount; i++) {
				let commandBytes = [];

				let commandByte = null;
				while (commandByte = output.shift()) {
					if (commandByte === DELIMITER) {
						processCommand(commandBytes);

						break;
					} else {
						commandBytes.push(commandByte);
					}
				}
			}
		}

		// TODOOOOOO
		if (serialEnd) {
			const startElements = document.getElementsByClassName("startContent");
			for (const element of startElements) {
				element.style.display = "none";
			}

			await fakeLoading(1250);

			startMain();

			return;
		}
	}
};

const dateRangeArray = ["Week", "Month", "Year"];
let dateIndex = 1;
const dateText = document.getElementById("dateText");
dateLeftContainer.onclick = () => {
	dateIndex -= 1;

	if (dateIndex < 0) {
		dateIndex = dateRangeArray.length - 1;
	}

	dateText.innerText = dateRangeArray[dateIndex];

	updateChart();
}
dateRightContainer.onclick = () => {
	dateIndex = (dateIndex + 1) % dateRangeArray.length;

	dateText.innerText = dateRangeArray[dateIndex];

	updateChart();
}

//const data = {};
// TODOOOO this is example data
// starts as Sunday, September 1, 2024 12:00:00 AM
window.data = {
	timeOffset: 1725148800,

	sleepQuality: [
		/*{
			time: 28_800, (8am)
			score: 0-4,
		}*/
	],
	dayQuality: [
		/*{
			time: 72_000, (1pm)
			score: 0-4,
		}*/
	],

	unhealthyFood: [],
	doomScrolling: [],
	drankCaffeine: [],
};

function getRandom(min, maxExcluded) {
	const r = Math.random();
	return Math.floor(r * maxExcluded) + min;
}

const SECONDS_IN_DAY = 86_400;

// fill test data for 270 days
for (let i = 0; i < 270; i++) {
	data.sleepQuality.push({
		time: getRandom(26_000, 32_000) + Date.now() / 1000 - SECONDS_IN_DAY * i,
		score: getRandom(1, 5),
	});

	data.dayQuality.push({
		time: getRandom(72_000, 72_200) + Date.now() / 1000 - SECONDS_IN_DAY * i,
		score: getRandom(1, 5),
	});

	const unhealthyFoodCount = getRandom(0, 3);
	data.unhealthyFood.push({ time: i * Date.now() / 1000 - SECONDS_IN_DAY * i, count: unhealthyFoodCount });
	/*for (let i = 0; i < unhealthyFoodCount; i++) {
		const timeOfDay = getRandom(28_800, 72_000);

		data.unhealthyFood.push({
			time: timeOfDay + i * SECONDS_IN_DAY,
		});
	}*/

	const doomScrollingCount = getRandom(0, 4);
	data.doomScrolling.push({ time: i * Date.now() / 1000 - SECONDS_IN_DAY * i, count: doomScrollingCount });
	/*for (let i = 0; i < doomScrollingCount; i++) {
		const timeOfDay = getRandom(28_800, 72_000);

		data.doomScrolling.push({
			time: timeOfDay + i * SECONDS_IN_DAY,
		});
	}*/

	const drankCaffeineCount = getRandom(0, 2);
	data.drankCaffeine.push({ time: i * Date.now() / 1000 - SECONDS_IN_DAY * i, count: drankCaffeineCount });
	/*for (let i = 0; i < drankCaffeineCount; i++) {
		const timeOfDay = getRandom(28_800, 72_000);

		data.drankCaffeine.push({
			time: timeOfDay + i * SECONDS_IN_DAY,
		});
	}*/
}

function processCommand(command) {
	console.log(command); return
	const bytes = new Uint8Array(command);
	const view = new DataView(bytes.buffer);

	const value = view.getUint16(0, true); // false → big-endian
	console.log(value);

	if (1) {
	}
}

async function fakeLoading(time) {
	const spinner = document.getElementById("spinner");

	document.body.style.backgroundImage = "url('background-loading.svg')";
	spinner.style.display = "block";

	await new Promise(resolve =>
		setTimeout(() => resolve(), time)
	);

	spinner.style.display = "none";
	document.body.style.backgroundImage = "url('background-main.svg')";
}

function startMain() {
	const mainContentElements = document.getElementsByClassName("mainContent");
	for (const element of mainContentElements) {
		element.style.display = "block";
	}

	updateChart();
}

let chart = null;
function updateChart() {
	chart && chart.destroy();

	const dayCount = [1, 7, 30][dateIndex];
	const dataCopy = structuredClone(data);
	const filteredData = {
		sleepQuality: [],
		dayQuality: [],

		unhealthyFood: [],
		doomScrolling: [],
		drankCaffeine: [],
	};

	let day = 0;
	while (day < dayCount) {
		const dataPoint = dataCopy.sleepQuality.pop();

		filteredData.sleepQuality.unshift(dataPoint);

		day++;
	}

	const statisticStartTime = filteredData.sleepQuality[0].time;
	const dataNames = Object.keys(filteredData).filter(name => name !== "sleepQuality");

	for (const dataName of dataNames) {
		for (const dataPoint of data[dataName]) {
			if (dataPoint.time > statisticStartTime) {
				filteredData[dataName].push(dataPoint);
			}
		}
	}

	console.log(filteredData)

	const timeDivisor = [SECONDS_IN_DAY, SECONDS_IN_DAY * 4, SECONDS_IN_DAY * 4 * 12][dateIndex];
	const timeAxis = [
		["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
		[...Object.keys(new Array(31 + 1).fill())].slice(1),
		["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
	][dateIndex];

	const timeAxisLabel = [
		"Day of the Week",
		"Days of September",
		"Time of Year",
	][dateIndex];

	function toTimeAxis(time) {
	}

	chart = new Chart(
		document.getElementById("mainGraph"),
		{
			options: {
				responsive: true,
				maintainAspectRatio: false,
				scales: {
					x: {
						ticks: {
							stepSize: 1,
							callback: function (value) {
								console.log(value)
								return timeAxis[value];
							}
						},
						title: {
							display: true,
							text: timeAxisLabel,
						}
					},
					y: {
						title: {
							display: true,
							text: "Score",
						},
					},
				},
			},
			type: 'line',
			data: {
				labels: timeAxis,
				datasets: [
					{
						label: 'Sleep (1-5)',
						data: filteredData.sleepQuality.map(e => {
							return {
								x: 0,
								y: e.score,
							};
						}),
						borderDash: [10, 5],
					},
					{
						label: 'Mood (1-5)',
						data: filteredData.dayQuality.map(o => {
							return {
								x: 0,
								y: o.score,
							};
						}),
					},
					{
						type: "bar",
						label: 'Unhealthy Food',
						data: filteredData.unhealthyFood.map(o => {
							return {
								x: 0,
								y: o.count,
							};
						}),
					},
					{
						type: "bar",
						label: 'Doomscrolling',
						data: filteredData.doomScrolling.map(o => {
							return {
								x: 0,
								y: o.count,
							};
						}),
					},
					{
						type: "bar",
						label: 'Caffeine',
						data: filteredData.drankCaffeine.map(o => {
							return {
								x: 0,
								y: o.count,
							};
						}),
					},
				]
			}
		}
	);
}